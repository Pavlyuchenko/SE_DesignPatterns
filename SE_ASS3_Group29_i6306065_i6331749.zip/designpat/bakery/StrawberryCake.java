/**
 * Group 29
 * Michal Pavlíček i6306065
 * Luuk Dobbelaar i6331749
 */
package designpat.bakery;

public class StrawberryCake extends Cake {
    public StrawberryCake() {
        super("Strawberry cake", 20);
    }
}