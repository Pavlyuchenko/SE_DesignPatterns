/**
 * Group 29
 * Michal Pavlíček i6306065
 * Luuk Dobbelaar i6331749
 */
package designpat.bakery;

public class ChocolateCake extends Cake {
    public ChocolateCake() {
        super("Chocolate cake");
    }
}
